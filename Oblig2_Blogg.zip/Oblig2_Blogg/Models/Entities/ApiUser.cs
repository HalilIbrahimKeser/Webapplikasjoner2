﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Oblig2_Blogg.Models.Entities
{
    //public class ApiUser
    //{
    //    public string Id { get; set; }
    //    public string Username { get; set; }
    //    public string Password { get; set; }
    //    public string Role { get; set; }
    //    public string Token { get; set; }
    //    public string FirstName { get; set; }
    //    public string SurName { get; set; }
    //    public DateTime? LastLoggedIn { get; set; }

    //    public bool? IsEnabled { get; set; }

    //    public bool? IsAdmin { get; set; }
    //}
}
